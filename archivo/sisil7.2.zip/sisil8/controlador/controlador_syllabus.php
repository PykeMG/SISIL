<?php
$error = array();
if (!empty($_POST["save_task"])){
  $nrc = $_POST['nrc'];  
  $curso = $_POST['curso'];
  $ciclo = $_POST['ciclo'];
  $id_usuario = $_SESSION['id'];
  $nombres = $_SESSION['nombres'];
  $apellidos = $_SESSION['apellidos'];
  $administrador = $nombres. " ". $apellidos;
  date_default_timezone_set("America/Lima");
  $fch_registro = date('Y-m-d H:i:s');

  $pdf=$_FILES['pdf']['name'];
  $pdf_type=$_FILES['pdf']['type'];
  $pdf_size=$_FILES['pdf']['size'];
  $pdf_tem_loc=$_FILES['pdf']['tmp_name'];
  $pdf_store="../../pdf/".$pdf;
  
  $size = 1024;

            
  if(isset($_FILES['pdf']) && $pdf_type == 'application/pdf'){
    if ($pdf_size < ($size * 2024)) {
        
        move_uploaded_file($pdf_tem_loc,$pdf_store);
        $sql="INSERT INTO syllabus(curso, ciclo, nombre, NRC, fch_registro, id_usuario, administrador) values('$curso','$ciclo','$pdf', '$nrc', '$fch_registro', '$id_usuario', '$administrador')";
        $query=mysqli_query($conexion,$sql);

        if($query){       
          
          header('location: adminSyllabus.php');
          echo "<div class='success'> Se almacenó el archivo correctamente </div>";
        }else{
          echo  "<div class='alert alert-danger'>Se produjo un error al enviar el archivo</div>";
          header('location: adminSyllabus.php');    
      } 

    }else{
      echo  "<div class='alert alert-danger'>Tamaño del archivo no debe superar los 2MB</div>";
      header('location: adminSyllabus.php');
    }

    }else if(isset($_FILES['pdf']) && $pdf_type != 'application/pdf'){
      echo  "<div class='alert alert-danger'>Solo se permiten archivos .pdf </div>";
      header('location: adminSyllabus.php');
  }

}
?>
