<!DOCTYPE html>
<!--
/* SISTEMA : Syllabus ISIL
/* SUBSISTEMA : Syllabus ISIL
/* NOMBRE : index.html
/* DESCRIPCIÓN : Barra de menu principal.
/* AUTOR : Jose Sanchez Tenaud ' SCRUM Master'
/* FECHA CREACIÓN : 23-11-2022
/* ------------------------------------------------------------------------*/
/* FECHA          EMPLEADO                    MODIFICACIÓN                       	 
/* ------------------------------------------------------------------------*/
-->
<div class="loader-container">
        <div class="loader"></div>
</div>