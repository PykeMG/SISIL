<?php  
session_start();
if (!empty($_POST["btningresar"])){
    if (!empty($_POST["correo"]) and !empty($_POST["password"])){
        $correo=$_POST["correo"];
        $password=md5($_POST["password"]);
        $sql=$conexion->query(" SELECT * FROM usuario WHERE correo= '$correo' AND password= '$password' ");
        if ($datos = $sql->fetch_object()){
            $fetch = mysqli_fetch_assoc($sql);
            $status = $datos->status;
            $rol = $datos->id_rol;
            if($status == 'verificado'){
                $_SESSION["id"]=$datos->id;
                $_SESSION["nombres"]=$datos->nombres;
                $_SESSION["apellidos"]=$datos->apellidos;
                $_SESSION["correo"]=$datos->correo;
                $_SESSION["password"]=$datos->password;
                $_SESSION["id_rol"]=$datos->id_rol;
                
                if($rol==1){
                    header('location: adminHome.php');
                }
                    else if($rol==2){
                        header('location:  home.php');
                    }
              }else{
                echo "<div class='error'>Cuenta no ha sido verificada</div>";
                header('location: verificacion.php');
              }

        } else {
            echo "<div class='error'>Usuario o Contraseña incorrectos</div>";
        }
    } else {
        echo "<div class='error'>Los campos están vacios</div>";

    }
}
?>