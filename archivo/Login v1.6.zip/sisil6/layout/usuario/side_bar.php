<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú lateral responsive - MagtimusPro</title>

    <link rel="stylesheet" href="../Styles/style_bar.css">
    <link rel="stylesheet" href="../Styles/style.css">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>
</head>
<body id="body">
<nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="img/LOGO-S.png" alt="logo" class="logo" srcset="">
                </span>

                <div class="text logo-text">
                    <span class="name">isil</span>
                    <span class="profession">syllabus</span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="home.php">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Principal</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="syllabus.php">
                            <i class='bx bx-file-blank icon'></i>
                            <span class="text nav-text">Syllabus</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="examenes.php">
                            <i class='bx bx-file icon' ></i>
                            <span class="text nav-text">Exámenes</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="proyectos.php">
                            <i class='bx bx-folder icon'></i>
                            <span class="text nav-text">proyectos</span>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="bottom-content">
                    <li class="nav-link">
                        <a href="perfil.php">
                            <i class='bx bx-user icon'></i>
                            <span class="text nav-text">
                            <?=
                                $_SESSION["nombres"]
                            ?>
                            </span>
                        </a>
                    </li>
                <li class="">
                    <a href="./controlador/controlador_cerrar_sesion.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Cerrar Sesión</span>
                    </a>
                </li>
            </div>
        </div>

    </nav>

    <script src="script.js"></script>
</body>
</html>