<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="Styles/style.css">
    <link rel="stylesheet" href="Styles/style_bar.css">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

    <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SISIL | Home</title>
    
</head>
<body>
    <?php
        session_start();
        if (empty($_SESSION["nombres"]) and empty($_SESSION["apellidos"])) {
            header('location: login.php');
        }
    ?>

    <?php
        require('layout/usuario/side_bar.php');
    ?>

    <div class="home">
            <div class="container py-2">
                <div class="layout-user">
                    <div class="title">
                        <h2>Perfil</h2>                     
                    </div>    
                    <?php 
                    include "modelo/conexion.php";
                    include "controlador/controlador_update_password.php";
                    ?>   
                    <div class="form">
                    <form action="" method="POST">
                        <div class=" form-floating mb-3">
                            <input type="text" class="form-control" value="<?=
                                        $_SESSION["nombres"]
                                        ?>"  disabled>
                            <label for="floatingInputI">Nombres</label>
                        </div>
                        <div class=" form-floating mb-3">
                            <input type="text" class="form-control" value="<?=
                                        $_SESSION["apellidos"]
                                        ?>"  disabled>
                            <label for="floatingInputI">Apellidos</label>
                        </div>
                        <div class=" form-floating mb-3">
                            <input type="text" class="form-control" value="<?=
                                        $_SESSION["correo"]
                                        ?>"  disabled>
                            <label for="floatingInputI">Correo Electronico</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Contraseña">
                            <label for="floatingPassword">Contraseña</label>
                            <div class="show-password fas fa-eye-slash"></div>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="password" name="cpassword" placeholder="Contraseña">
                            <label for="floatingPassword">Confirmar contraseña</label>                  
                        </div>
                        <div class="mb-3">
                            <input type="submit" name="btncambiapass" 
                            class="btn btn-primary py-3 col-12"value="Actualizar " disabled>
                        </div>
                    </form>
                    </div>
                </div><!--card-->    
            </div>
    </div>


    <script src="layout/js/script.js"></script>
    <script>
      var fields = document.querySelectorAll(".form-floating input");
      var btn = document.querySelector(".btn");
      function check(){
        if(fields[3].value != "" && fields[4].value != "" )
          btn.disabled = false;
        else
          btn.disabled = true;  
    }

    fields[3].addEventListener("keyup",check);
    fields[4].addEventListener("keyup",check);

    document.querySelector(".show-password").addEventListener("click",function(){
      if(this.classList[2] == "fa-eye-slash"){
        this.classList.remove("fa-eye-slash");
        this.classList.add("fa-eye");
        fields[3].type = "text";
        fields[4].type = "text";
      }else{
        this.classList.remove("fa-eye");
        this.classList.add("fa-eye-slash");
        fields[3].type = "password";
        fields[4].type = "password";
      }
    });
    </script>
    <!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</body>
</html>