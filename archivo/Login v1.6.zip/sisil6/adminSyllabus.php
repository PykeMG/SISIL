<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="Styles/style.css">
    <link rel="stylesheet" href="Styles/style_bar.css">
    <!-- CSS only -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SISIL | Home</title>
    
</head>
<body>
    <?php
        session_start();
        if (empty($_SESSION["nombres"]) and empty($_SESSION["apellidos"])) {
            header('location: login.php');
        }
    ?>

    <?php
        require('layout/admin/side_bar_admin.php');
        ?>

    <?php
        include('modelo/conexion.php');

        $tmp = array();
        $res = array();

        $sel = $conexion->query("SELECT * FROM syllabus");
        while ($row = $sel->fetch_assoc()) {
            $tmp = $row;
        array_push($res, $tmp);
        }
    ?>

    <div class="home">
        <div class="container py-5">
            <h2>Syllabus</h2>
            <form  name="formulario" id="formulario" action="syllabus.php" method="post" enctype="multipart/form-data">
            <div class="row mb-3">
                <div class="form-floating row_col col">
                    <select class="form-select" aria-label="NRC del curso" name="nrc" id="nrc">
                                        <option selected>NRC del curso</option>
                                        <?php
                                            include("modelo/conexion.php");    
                                            $nrc = "SELECT * FROM curso";
                                            $resultado = mysqli_query($conexion,$nrc);
                                            
                                            while ($valores = mysqli_fetch_array($resultado)){
                                                $nrc = $valores['nrc_curso'];

                                                ?>
                                                <option value="<?php echo $nrc; ?>"><?php echo $nrc; ?></option>
                                                <?php
                                            }
                                        ?>
                    </select>
                    <label for="floatingSelect">NRC</label>
                </div>
                <div class="form-floating row_col col">
                    <select class="form-select" aria-label="Nombre del curso" name="curso">
                                        <option selected>Curso</option>
                                        <?php
                                            include("modelo/conexion.php");  
                                            
                                            $cursos = "SELECT nom_curso FROM curso";
                                            $resultado = mysqli_query($conexion,$cursos);
                                            
                                            while ($valores = mysqli_fetch_array($resultado)){
                                                $nom_curso = $valores['nom_curso'];

                                                ?>
                                                <option value="<?php echo $nom_curso; ?>"><?php echo $nom_curso; ?></option>
                                                <?php
                                            }
                                        ?>
                    </select>
                    <label for="floatingSelect">Curso</label>
                </div>
            </div>   
            <div class="row mb-3">
                <div class="form-floating row_col col">
                    <select class="form-select" aria-label="Ciclo del curso" name="ciclo">
                                        <option selected>Ciclo</option>
                                        <?php
                                            include("modelo/conexion.php");    
                                            $ciclo = "SELECT * FROM ciclo";
                                            $resultado = mysqli_query($conexion,$ciclo);
                                            
                                            while ($valores = mysqli_fetch_array($resultado)){
                                                $id = $valores['id_ciclo'];
                                                $nombre = $valores['ciclo'];

                                                ?>
                                                <option value="<?php echo $nombre; ?>"><?php echo $nombre; ?></option>
                                                <?php
                                            }
                                        ?>
                    </select>
                    <label for="floatingSelect">Ciclo</label>
                </div>
            </div>  
                <div class="mb-3">
                    <label for="formFileMultiple" class="form-label">Peso máximo 2MB</label>
                    <input class="form-control" type="file" id="pdf" name="pdf" required>
                </div>

                <div class="mb-3">
                    <button type="submit" id="upload" class="btn btn-primary py-3 col-12" name="submit" value="Upload">Subir Syllabus</button>
                    <?php

                            if (isset($_POST['submit'])) {

                                $curso=$_POST['curso'];
                                $ciclo=$_POST['ciclo'];


                                $pdf=$_FILES['pdf']['name'];
                                $pdf_type=$_FILES['pdf']['type'];
                                $pdf_size=$_FILES['pdf']['size'];
                                $pdf_tem_loc=$_FILES['pdf']['tmp_name'];
                                $pdf_store="pdf/".$pdf;
                                
                                $size = 1024;
                                if(isset($_FILES['pdf']) && $pdf_type == 'application/pdf'){
                                    if ($pdf_size < ($size * 2024)) {
                                        
                                        move_uploaded_file($pdf_tem_loc,$pdf_store);
                                        $sql="INSERT INTO syllabus(curso, ciclo, nombre) values('$curso','$ciclo','$pdf')";
                                        $query=mysqli_query($conexion,$sql);

                                        if($query){       
                                            echo "<div class='alert alert-success'>Almacenado correctamente</div>";
                                        }else{
                                            echo  "<div class='alert alert-danger'>Se produjo un error al guardar el archivo</div>";
                                        } 

                                    }else{
                                        echo  "<div class='alert alert-danger'>Tamaño del archivo no debe superar los 2MB</div>";
                                    }

                                }else if(isset($_FILES['pdf']) && $pdf_type != 'application/pdf'){
                                    echo  "<div class='alert alert-danger'>Solo se permiten archivos .pdf </div>";
                                }                                   

                            }

                    ?>

                </div>
            </form> 
        </div>
        <div class="container margin-top">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Curso</th>
                    <th scope="col">Ciclo</th>
                    <th scope="col">Documento</th>
                    <th scope="col">Modal</th>
                    <th scope="col">Otra Pagina</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($res as $val) { ?>
                        <tr>
                            <td><?php echo $val['id_syllabus'] ?> </td>
                            <td><?php echo $val['curso'] ?></td>
                            <td><?php echo $val['ciclo'] ?></td>
                            <td><?php echo $val['nombre'] ?></td>
                            <td>
                                <button onclick="openModelPDF('<?php echo $val['nombre'] ?>')" class="btn btn-primary" type="button">Modal</button>
                                
                            </td>
                            <td>
                                <a class="btn btn-primary" target="_black" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . '/version4/Login/pdf/' . $val['nombre']; ?>" >Otra pagina</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!--- Modal -->
    <div class="modal fade modal-xl" id="modalPdf" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <iframe id="iframePDF" frameborder="0" scrolling="no" width="100%" height="500px"></iframe>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
    
    
    <script src="layout/js/script.js"></script>
    <script>
        var fields = document.querySelectorAll(".form-floating select");
      var btn = document.querySelector(".btn");
      function check(){
        if(fields[2].value != "")
          btn.disabled = false;
        else
          btn.disabled = true;  
    }

    fields[2].addEventListener("keyup",check);
    </script>

    <script>
            function openModelPDF(nombre) {
        $('#modalPdf').modal('show');
        $('#iframePDF').attr('src','<?php echo 'http://' . $_SERVER['HTTP_HOST'] . '/version4/Login/pdf/'; ?>'+nombre);
    }
    </script>
    <!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>               
</body>
</html>




